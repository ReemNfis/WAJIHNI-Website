package com.example.wajihni.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@ToString
@Table(name="officeInfo")

public class OfficeInfo {

    @Id
    private String floorNumber;
    private String officeName;
    private String officeNumber;
    private String circuitNumber;
    
    public void setFloorNumber(String floorNumber){
        this.floorNumber = floorNumber;
    }
    public void setOfficeName(String officeName){
        this.officeName = officeName;
    }
    public void setCircuitNumber(String circuitNumber){
        this.circuitNumber = circuitNumber;
    }
    public void setOfficeNumber(String officeNumber){
        this.officeNumber = officeNumber;
    }

    public String getEmployeeName(){
        return floorNumber;
    }
    public String getOfficeName(){
        return officeName;
    }
    public String getOfficeNumber(){
        return officeNumber;
    }
    public String getCircuitNumber(){
        return circuitNumber;
    }


}