package com.example.wajihni.controller;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.wajihni.entity.OfficeInfo;
import com.example.wajihni.repo.OfficeService;

@Controller
public class OfficeInfoController {
     
    @Autowired 
    private OfficeService productService;
     
    @RequestMapping(path = {"/","/search"})
    //@GetMapping("/search")

    public String home(OfficeInfo officeInfo1, Model model, String keyword) {
        //if(keyword!=null) {
        //  List<OfficeInfo> list = productService.getByKeyword(keyword);
        //  model.addAttribute("list", list);
        // }else {
        List<OfficeInfo> list = productService.getAllOffices();
        model.addAttribute("list", list);
        return "displayResult.html";
       }
 
     
}