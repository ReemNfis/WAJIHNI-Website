package com.example.wajihni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WajihniApplication {

	public static void main(String[] args) {
		SpringApplication.run(WajihniApplication.class, args);
	}

}
