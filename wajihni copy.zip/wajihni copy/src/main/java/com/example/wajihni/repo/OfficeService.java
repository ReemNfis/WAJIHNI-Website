package com.example.wajihni.repo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.wajihni.entity.OfficeInfo;
 

 
@Service
public class OfficeService {

    @Autowired
    private OfficeRepo repo;

    public List<OfficeInfo> getAllOffices(){
        List<OfficeInfo> list =  (List<OfficeInfo>)repo.findAll();
        return list;
    }
     
    public List<OfficeInfo> getByKeyword(String keyword){
        return repo.findByKeyword(keyword);
    }
  
}