package com.example.wajihni.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.wajihni.entity.OfficeInfo;
 
 @Repository
public interface OfficeRepo extends JpaRepository<OfficeInfo, Integer> {
     
    @Query(value = "select * from sql12619500 s where s.floorNumber like %:keyword% or s.circuitNumber like %:keyword% or s.officeNumber like %:keyword% or s.OfficeName like %:keyword%", nativeQuery = true) 

   List<OfficeInfo> findByKeyword(@Param("keyword") String keyword);
     
}