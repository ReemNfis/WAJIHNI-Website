package com.example.wajihni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WajihniApplicationTests {

	@Test
	void contextLoads() {
	}

}
